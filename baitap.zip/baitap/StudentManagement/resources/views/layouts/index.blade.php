<!DOCTYPE html> <html lang="en"> <head> <meta charset="UTF-8"> <meta name="viewport" content="width=device-width,
    initial-scale=1.0"> <title>baitap</title> </head> <body> @extends('layouts.app') @section('content') <h2>Danh sách
    Sinh viên</h2> <a href="{{ route('students.create') }}" class="btn btn-success">Thêm mới</a>
<table class="table
    mt-3"> <thead> <tr> <th>ID</th> <th>Tên< /th>
    <th>Tuổi</th>
    <th>Địa chỉ</th>
    <th>Hành động</th> </tr> </thead>
    <tbody> @foreach ($students as $student) <tr>
    <td>{{ $student->id }}</td>
    <td>{{ $student->studentname }}</td>
    <td>{{ $student->studentage }}</td>
    <td>{{ $student->address }}</td> <td> <a href=" {{ route('students.edit', $student->id) }}"
    class="btn btn-primary">Sửa
    </a>
    <form action="{{ route('students.destroy', $student->id) }}" method="POST" class="d-inline"> @csrf @method('DELETE')
        <button type="submit" class="btn btn-danger" onclick="return confirm('Bạn chắc chắn muốn xóa?')">Xóa</button>
        </form> </td>
        </tr> @endforeach </tbody>
</table>
</body>

</html> @endsection