<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head> 
<body>
    

@extends('layouts.app')

@section('content')
    <h2>Thêm mới Sinh viên</h2>

    <form action="{{ route('students.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="studentname">Tên Sinh viên:</label>
            <input type="text" name="studentname" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="studentage">Tuổi:</label>
            <input type="number" name="studentage" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="address">Địa chỉ:</label>
            <input type="text" name="address" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Thêm mới</button>
    </form>
</body>
</html>
@endsection
